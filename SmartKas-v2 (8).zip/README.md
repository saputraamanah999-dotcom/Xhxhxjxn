# SmartKas School — SMK TI Bali Global Karangasem

Sistem Manajemen Uang Kas Sekolah Realtime & Transparan.

Dibangun dengan **Vite + React + TypeScript + Tailwind CSS v4 + Firebase** (Auth, Firestore, Storage).

## Fitur Utama

- **Multi-tenant** — satu admin bisa kelola banyak sekolah, kelas, jurusan.
- **Realtime** — semua data kas, siswa, pembayaran, pengeluaran sync realtime via Firestore `onSnapshot`.
- **3 role**: Admin (kepala sekolah), Guru Wali Kelas, Bendahara Kelas.
- **Matriks Checkbox Kas Mingguan** — bendahara centang langsung di tabel spreadsheet.
- **Peraturan Kas Editable** — bendahara bisa ubah nominal kas mingguan per kelas (5k → 7k → dst), otomatis berlaku ke semua siswa.
- **Anti Inspect / Anti DevTools** — F12, Ctrl+Shift+I/J/C, Ctrl+U, right-click diblokir. DevTools-detected via debugger timing & window-size gap.
- **Firebase Auth Real** — login email+password (bukan demo).
- **Bootstrap Admin** — first-run mode via tab "Setup Admin Pertama" di halaman login.

## Login Admin

```
Email    : saputraamanah999@gmail.com
Password : saputra123@
```

Akun ini sudah dibuat di Firebase Auth + Firestore `users/{uid}` dengan `role: admin`.

## Run Locally

**Prerequisites**: Node.js 18+, bun (atau npm).

```bash
# 1. Install dependencies
bun install         # atau: npm install

# 2. Jalankan dev server
bun run dev         # atau: npm run dev
# Buka http://localhost:3000

# 3. Build production
bun run build       # output ke /dist

# 4. Preview production build
bun run preview
```

## Setup Pertama Kali (Penting!)

### A. Deploy Firestore Rules

Rules baru memperbaiki error `FirebaseError: Missing or insufficient permissions`:

```bash
# Install Firebase CLI (sekali saja)
npm install -g firebase-tools

# Login ke Firebase (sekali saja)
firebase login

# Pilih project bendahara-3e921 (atau buat baru)
firebase use --add bendahara-3e921

# Deploy rules
firebase deploy --only firestore:rules
```

### B. Enable Email/Password Auth Provider

1. Buka **Firebase Console** → project `bendahara-3e921`.
2. **Authentication** → **Sign-in method**.
3. Klik **Email/Password** → **Enable** → **Save**.

### C. Buat Admin (3 cara, pilih salah satu)

**Cara 1 — Pakai UI di aplikasi (paling mudah):**
1. Buka aplikasi di browser.
2. Di halaman Login, klik tab **"Setup Admin Pertama"**.
3. Isi: `saputraamanah999@gmail.com` / `saputra123@` / Nama Admin / `SMK TI Bali Global Karangasem` / `smk-ti-bali-karangasem`.
4. Klik **"Buat Akun Admin & Masuk"**.

**Cara 2 — Pakai script Node (bootstrap-admin.mjs):**
```bash
node scripts/bootstrap-admin.mjs
# Default: saputraamanah999@gmail.com / saputra123@
# Bisa override: --email ... --password ... --nama ... --sekolahId ... --sekolahNama ...
```

**Cara 3 — Pakai Firebase Console:**
1. Firebase Console → Authentication → Users → Add User.
2. Isi email + password.
3. Setelah user dibuat, jalankan script di Cara 2 (akan deteksi user exists dan menulis profile doc).

## Struktur Folder

```
project/
├── firestore.rules              ← Rules security (DEPLOY INI!)
├── storage.rules                ← Rules Storage
├── firebase.json                ← Config deploy (hosting + firestore + storage)
├── firestore.indexes.json
├── index.html                   ← favicon + manifest + anti-inspect script
├── public/
│   ├── manifest.json            ← PWA manifest
│   ├── favicon.ico              ← legacy favicon
│   ├── favicon-16.png           ← 16x16
│   ├── favicon-32.png           ← 32x32
│   ├── favicon-48.png           ← 48x48
│   ├── favicon-192.png          ← 192x192 (Android icon)
│   ├── favicon-512.png          ← 512x512 (PWA icon)
│   ├── apple-touch-icon.png     ← 180x180 (iOS)
│   └── favicon.jpg              ← source logo (SMK TI Bali)
├── scripts/
│   └── bootstrap-admin.mjs      ← one-time admin creation
├── src/
│   ├── contexts/AuthContext.tsx     ← Firebase Auth + first-run bootstrap
│   ├── hooks/useSafeCollection.ts   ← Firestore onSnapshot (no demo fallback)
│   ├── lib/firebase/                ← config, auth, firestore, seed, localData
│   ├── components/
│   │   ├── forms/                   ← SiswaForm, PembayaranForm, dst.
│   │   ├── tables/                  ← KasMatrixTable (checkbox), SiswaTable, dst.
│   │   ├── shared/                  ← Sidebar, Navbar, GlobalSearchBar, ConnectionStatus
│   │   └── pages/
│   │       ├── auth/LoginPage.tsx   ← Login + Setup Admin Pertama Kali
│   │       ├── admin/               ← 11 admin pages
│   │       ├── guru/                ← 5 guru pages
│   │       └── bendahara/           ← 6 bendahara pages
│   └── types/                       ← TypeScript interfaces
└── dist/                            ← build output (jangan edit manual)
```

## Security Best Practices

Sudah diterapkan di proyek ini:

### Client-side hardening
- ❌ Right-click diblokir (kecuali di input/textarea).
- ❌ F12, Ctrl+Shift+I/J/C, Ctrl+U, Ctrl+S diblokir.
- ❌ Drag-and-drop gambar/link keluar halaman diblokir.
- 🚨 DevTools detection via `debugger` timing + window-size gap → halaman diganti dengan "Security Violation".
- ⚠️ Console warning banner ("STOP — ini scam").
- 🧹 `console.clear()` setiap 5 detik.

### Server-side hardening
- ✅ **Firestore Rules** — multi-tenant isolation by `sekolahId`. Lihat `firestore.rules`.
- ✅ **Firebase Auth** real — password di-hash oleh Firebase, bukan plaintext.
- ✅ **HTTPS-only hosting** via Firebase Hosting (otomatis).
- ✅ **Security headers**: `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`, `Referrer-Policy: no-referrer`, `Permissions-Policy: geolocation=(),microphone=(),camera=()`.

### Yang HARUS Anda lakukan sendiri
1. **Set custom claims** untuk role admin via Firebase Admin SDK (Cloud Function) — saat ini role dibaca dari Firestore `users/{uid}.role`. Untuk keamanan ekstra, set custom claim `role: 'admin'` ke admin user via Admin SDK:
   ```js
   // Di Cloud Function atau script lokal dengan Admin SDK
   admin.auth().setCustomUserClaims(uid, { role: 'admin', schoolId: 'smk-ti-bali-karangasem' });
   ```
2. **Rate-limiting auth** — Firebase Auth punya built-in quota, tapi tambahkan App Check untuk mencegah abuse.
3. **Backup otomatis** — enable Firestore scheduled exports ke Cloud Storage.
4. **Jangan pernah** commit file `.env` dengan credentials ke git.

### Catatan tentang "Anti Inspect"
Semua client-side protection hanyalah **deterrent**, bukan absolute. User yang tekun masih bisa:
- Membuka tab baru, navigate ke `view-source:URL`.
- Mematikan JavaScript, lalu lihat HTML.
- Pakai curl/wget untuk ambil bundle JS.

Karena itu **secrets sensitif (service account key, credentials database)** HARUS di server-side (Cloud Functions / Firestore Rules), JANGAN di client code. Firebase Web API Key yang terlihat di bundle memang dirancang publik — keamanan datang dari Firestore Rules, bukan dari menyembunyikan API Key.

## Yang Diperbaiki dari Versi Sebelumnya

1. ✅ **Manifest.json syntax error** — dibuat ulang dengan format valid.
2. ✅ **Favicon** — pakai logo SMK TI Bali (multi-size PNG + ICO).
3. ✅ **FirebaseError: Missing or insufficient permissions** — firestore.rules diperbarui, hanya authenticated users yang boleh akses.
4. ✅ **Mode demo dihapus** — useSafeCollection tidak lagi pakai LOCAL_* fallback. Real Firebase only.
5. ✅ **Login sekarang real Firebase Auth** — password dicek, bukan diabaikan.
6. ✅ **Checkbox gagal render** — KasMatrixTable sekarang pakai `nominalKasMingguan` dinamis (sebelumnya hardcode "Rp 5.000").
7. ✅ **Bendahara bisa edit peraturan kas** — halaman Target & Peraturan Kas kelas, dengan quick-set 2k/3k/5k/7k/10k/15k/20k.
8. ✅ **Form tambah siswa disederhanakan** — cukup Nama + No Absen. Jurusan & Kelas auto-isi dari konteks.
9. ✅ **Error validasi "56000 not valid value"** — `step={500/1000/50000}` dihapus dari semua input currency. Sekarang `step="any"`.
10. ✅ **Anti-inspect / anti-devtools** — script keamanan di `index.html`.
11. ✅ **Anti Firebase key exposure** — penjelasan di README: Web API Key memang publik, keamanan datang dari Firestore Rules.

## Lisensi

Internal use untuk SMK TI Bali Global Karangasem.
